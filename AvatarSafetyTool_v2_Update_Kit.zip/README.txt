Avatar Safety Tool v2.0 - update kit
====================================
(1) Easiest: copy  AvatarSafetyTool.cs  (the separate file) into  Assets/Editor  . Delete the old v1 file first.
    Menu: Tools > Avatar Safety Tool

(2) GitHub repo (avatar-safety-tool): replace the files with the ones in  git-repo/  :
      package.json            (version is now 2.0.0)
      Editor/AvatarSafetyTool.cs
      Editor/AvatarSafetyTool.Editor.asmdef
    Then in Unity: Package Manager > Add package from git URL again (or press the update arrow).

(3) VCC list (optional):
      - GitHub > avatar-safety-tool > Releases > Create new release, tag  v2.0.0 , attach  vpm/local.avatarsafetytool-2.0.0.zip
      - In repo  bwdwuw-design.github.io  replace  vpm-repos/main.json  with  vpm/main.json
